# Beexter Identity — GET /v1/me

This overlay adds the authenticated basic identity profile endpoint without changing the locked PostgreSQL schema.

## Endpoint

```http
GET /v1/me
Authorization: Bearer <access_token>
```

Response fields:

- `id`
- `email`
- `role`
- `status`
- `email_verified`
- `created_at`
- `updated_at`

The response does not expose password hashes, access/refresh tokens, session state, `deleted_at`, or `soft_delete_count`.

## Apply

From the repository root:

```bash
rm -rf /tmp/beexter-me-step
unzip -o ./beexter-me-step.zip -d /tmp
cp -a /tmp/beexter-me-step/service/identity/. ./service/identity/
```

## Verify

```bash
cd service/identity
gofmt -w ./cmd ./internal
go mod tidy
go test ./...
go test -race ./...
go vet ./...
```

No migration or environment variable is required.
