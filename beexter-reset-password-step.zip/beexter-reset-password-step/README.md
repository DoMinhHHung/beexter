# Beexter Identity — Reset Password Step

This overlay implements `POST /v1/auth/reset-password` without changing the
PostgreSQL schema and without adding a migration.

## Behavior

- Sliding-window Redis rate limiting by IP; Redis failures are fail-closed.
- Canonical UUID v7 password-reset token validation.
- Existing password policy validation.
- Argon2id hashing through the existing password hasher.
- Password-reset token validation and one-time consumption under PostgreSQL
  row locks.
- Password hash update, token consumption, sibling token revocation and durable
  session-revocation scheduling in one PostgreSQL transaction.
- Immediate refresh-session revocation before the database mutation.
- Delayed, retryable cleanup of sessions created by an in-flight login.
- Existing access tokens are not blacklisted and may remain valid until their
  one-hour expiration.

## Important Outbox design

The locked database schema only allows these Outbox event types:

- `identity.email_verification_requested`
- `identity.password_reset_requested`

The implementation therefore does not invent a third event type. After a
successful reset, the transaction reopens the password-reset Outbox row and
changes its JSON payload to phase `session_revocation`, with a
`session_cutoff`. The worker then revokes Redis sessions created at or before
that cutoff and retries through the existing Outbox backoff mechanism.

## Apply

Run from the repository root:

```bash
rm -rf /tmp/beexter-reset-password-step
unzip -o /path/to/beexter-reset-password-step.zip -d /tmp
cp -a /tmp/beexter-reset-password-step/service/identity/. service/identity/
```

Review:

```bash
git status --short
git diff --stat
git diff --check
git diff -- service/identity/migrations
```

The migration diff must be empty.

## Environment

Add or keep these values in `service/identity/.env`:

```dotenv
RESET_PASSWORD_RATE_LIMIT_IP_REQUESTS=5
RESET_PASSWORD_RATE_LIMIT_IP_WINDOW=15m
```

## Automated verification

```bash
cd service/identity

gofmt -w ./cmd ./internal
go mod tidy

go test ./...
go test -race ./...
go vet ./...
```

## Run

```bash
set -a
source .env
set +a

go run ./cmd/api
```

Health checks:

```bash
curl -i http://localhost:8080/health
curl -i http://localhost:8080/ready
```

## Manual reset test

Obtain an active reset token from the localized email, or in development:

```sql
SELECT
    token.id,
    account.email,
    token.expires_at,
    token.used_at,
    token.revoked_at
FROM identity.password_reset_tokens AS token
JOIN identity.identities AS account
    ON account.id = token.identity_id
WHERE token.used_at IS NULL
  AND token.revoked_at IS NULL
  AND token.expires_at > CURRENT_TIMESTAMP
ORDER BY token.created_at DESC
LIMIT 1;
```

Call reset-password:

```bash
curl -i \
  -X POST \
  http://localhost:8080/v1/auth/reset-password \
  -H 'Content-Type: application/json' \
  -d '{
    "token": "<password-reset-token-uuid-v7>",
    "new_password": "Secure2!"
  }'
```

Expected:

```text
200 OK
{"data":{"password_reset":true}}
```

Calling the same token again must return:

```text
401 Unauthorized
ERR_TOKEN_INVALID
```

An expired token must return `ERR_TOKEN_EXPIRED`. A weak password must return
`ERR_INVALID_INPUT`.

## Database checks

```sql
SELECT
    account.email,
    account.updated_at,
    token.used_at,
    token.revoked_at
FROM identity.password_reset_tokens AS token
JOIN identity.identities AS account
    ON account.id = token.identity_id
WHERE token.id = '<password-reset-token-uuid-v7>';
```

Expected:

- `used_at IS NOT NULL`
- `revoked_at IS NULL`
- the identity password hash is Argon2id
- other active password-reset tokens for the identity are revoked

Inspect the reused Outbox row:

```sql
SELECT
    id,
    event_type,
    payload,
    attempt_count,
    available_at,
    processed_at,
    last_error
FROM identity.outbox_events
WHERE event_type = 'identity.password_reset_requested'
  AND payload ->> 'token_id' = '<password-reset-token-uuid-v7>';
```

After the reset transaction, payload contains:

```json
{
  "phase": "session_revocation",
  "session_cutoff": "RFC3339"
}
```

After the worker succeeds, `processed_at` is non-null and `last_error` is null.

## Session checks

A refresh token obtained before reset must fail after reset:

```bash
curl -i \
  -X POST \
  http://localhost:8080/v1/auth/refresh \
  -H 'Content-Type: application/json' \
  -d '{"refresh_token":"<old-refresh-token>"}'
```

The old password must fail login and the new password must succeed. Access
JWTs already issued before reset remain valid until expiration because the
project intentionally has no access-token blacklist.

## Commit

```bash
git add -A
git commit -m "feat(identity): reset passwords and revoke sessions"
git push
```
