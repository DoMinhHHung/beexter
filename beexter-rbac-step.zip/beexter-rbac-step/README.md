# Beexter Identity — Simple RBAC and privileged identity creation

This overlay is based on the local reset-password step and preserves its
composition-root/router changes. It does not overwrite the Redis session
rotation hotfix.

## Scope

- Adds reusable role authorization middleware.
- Adds `POST /v1/admin/identities`.
- Enforces the locked hierarchy:
  - `ADMIN` may create `VICE_ADMIN` and `AGENCY`.
  - `VICE_ADMIN` may create `AGENCY`.
  - The endpoint cannot create `ADMIN`, `CLIENT`, or `JOB_SEEKER`.
- Creates identity, email-verification token, and existing verification Outbox
  event in one PostgreSQL transaction.
- Sends the existing localized verification email.
- Does not change schema and contains no migration.
- Does not add a policy engine or ABAC layer.

## Apply

From the repository root:

```bash
cd /run/media/hungbe/WORKSPACE2/Works/beexter
rm -rf /tmp/beexter-rbac-step
unzip -o ./beexter-rbac-step.zip -d /tmp
cp -a /tmp/beexter-rbac-step/service/identity/. ./service/identity/
```

## Verify source

```bash
git status --short
git diff --stat
git diff --check
git diff -- service/identity/migrations
```

The migration diff must be empty.

## Automated tests

```bash
cd service/identity
gofmt -w ./cmd ./internal
go mod tidy
go test ./...
go test -race ./...
go vet ./...
```

## Run

```bash
set -a
source .env
set +a
go run ./cmd/api
```

## Local ADMIN bootstrap

The HTTP API intentionally cannot create `ADMIN`. For local development only,
use an existing active, email-verified account and change its role directly:

```sql
UPDATE identity.identities
SET
    role = 'ADMIN',
    updated_at = CURRENT_TIMESTAMP
WHERE email = 'admin@example.com'
  AND status = 'active'
  AND deleted_at IS NULL
RETURNING id, email, role, email_verified_at;
```

Log in again after changing the role. Authentication rejects access tokens with
stale role claims.

Production ADMIN provisioning must be performed by a separate trusted bootstrap
procedure, not by the public or privileged identity endpoints.

## Create an AGENCY as ADMIN

```bash
LOGIN_JSON=$(curl -sS \
  -X POST \
  http://localhost:8080/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{
    "email": "admin@example.com",
    "password": "Secure1!"
  }')

ADMIN_ACCESS_TOKEN=$(printf '%s' "$LOGIN_JSON" | jq -r '.data.access_token')

curl -i \
  -X POST \
  http://localhost:8080/v1/admin/identities \
  -H "Authorization: Bearer $ADMIN_ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -H 'Accept-Language: vi-VN' \
  -d '{
    "email": "agency@example.com",
    "password": "Secure1!",
    "role": "AGENCY"
  }'
```

Expected:

```text
201 Created
```

```json
{
  "data": {
    "id": "<uuid-v7>",
    "email": "agency@example.com",
    "role": "AGENCY",
    "email_verified": false
  }
}
```

The new identity cannot authenticate until it verifies its email.

## Role matrix

| Actor | Target | Expected |
|---|---|---|
| ADMIN | AGENCY | 201 |
| ADMIN | VICE_ADMIN | 201 |
| ADMIN | ADMIN | 403 |
| ADMIN | CLIENT | 403 |
| ADMIN | JOB_SEEKER | 403 |
| VICE_ADMIN | AGENCY | 201 |
| VICE_ADMIN | VICE_ADMIN | 403 |
| CLIENT/JOB_SEEKER/AGENCY | Any privileged role | 403 |

Unknown role text such as `SUPER_ADMIN` returns `400 ERR_INVALID_INPUT`.
A duplicate email returns `409 ERR_EMAIL_ALREADY_EXISTS`.

## Verify PostgreSQL and Outbox

```sql
SELECT
    id,
    email,
    role,
    status,
    email_verified_at,
    created_at
FROM identity.identities
WHERE email = 'agency@example.com';
```

```sql
SELECT
    id,
    aggregate_id,
    event_type,
    payload,
    processed_at,
    last_error
FROM identity.outbox_events
WHERE aggregate_id = (
    SELECT id
    FROM identity.identities
    WHERE email = 'agency@example.com'
)
ORDER BY created_at DESC;
```

The event type remains:

```text
identity.email_verification_requested
```

## Commit

```bash
git add -A
git commit -m "feat(identity): enforce role hierarchy for privileged identities"
git push
```
